package com.daftar60.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Daftar60App(this) }
    }
}

class AppStore(context: Context) {
    private val p = context.getSharedPreferences("daftar60", Context.MODE_PRIVATE)
    var registeredDays: Int
        get() = p.getInt("registeredDays", 0)
        set(v) { p.edit().putInt("registeredDays", v.coerceIn(0,60)).apply() }
    var hunger: Int
        get() = p.getInt("hunger", 5)
        set(v) { p.edit().putInt("hunger", v).apply() }
    var fullness: Int
        get() = p.getInt("fullness", 5)
        set(v) { p.edit().putInt("fullness", v).apply() }
    var emotional: Boolean
        get() = p.getBoolean("emotional", false)
        set(v) { p.edit().putBoolean("emotional", v).apply() }
    var mindful: Boolean
        get() = p.getBoolean("mindful", false)
        set(v) { p.edit().putBoolean("mindful", v).apply() }
    var paused: Boolean
        get() = p.getBoolean("paused", false)
        set(v) { p.edit().putBoolean("paused", v).apply() }
    var satisfiedStop: Boolean
        get() = p.getBoolean("satisfiedStop", false)
        set(v) { p.edit().putBoolean("satisfiedStop", v).apply() }
    var note: String
        get() = p.getString("note", "") ?: ""
        set(v) { p.edit().putString("note", v).apply() }
}

@Composable
fun Daftar60App(context: Context) {
    val store = remember { AppStore(context) }
    var tab by remember { mutableIntStateOf(0) }

    MaterialTheme {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    val items = listOf(
                        Triple("امروز", Icons.Default.Home, 0),
                        Triple("ثبت", Icons.Default.Edit, 1),
                        Triple("پیشرفت", Icons.Default.BarChart, 2),
                        Triple("راهنما", Icons.Default.Info, 3)
                    )
                    items.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item.third,
                            onClick = { tab = item.third },
                            icon = { Icon(item.second, null) },
                            label = { Text(item.first) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when(tab) {
                    0 -> HomeScreen(store) { tab = 1 }
                    1 -> DailyEntryScreen(store) { tab = 0 }
                    2 -> ProgressScreen(store)
                    else -> GuideScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(store: AppStore, onRegister: () -> Unit) {
    var days by remember { mutableIntStateOf(store.registeredDays) }
    val progress = days / 60f
    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("دفتر ۶۰ روزه کنترل اشتها", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        CircularProgressIndicator(progress = { progress }, modifier = Modifier.size(128.dp))
        Spacer(Modifier.height(12.dp))
        Text("روز ${maxOf(1, days + 1)} از ۶۰", style = MaterialTheme.typography.titleLarge)
        Text("${(progress*100).roundToInt()}٪ مسیر ثبت شده", textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("ثبت وضعیت امروز", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text("چند دقیقه برای شناخت بهتر گرسنگی، سیری و الگوهای خوردن خود وقت بگذارید.")
                Spacer(Modifier.height(12.dp))
                Button(onClick = onRegister, modifier = Modifier.fillMaxWidth()) {
                    Text("شروع ثبت امروز")
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("یادآوری امروز 🌱", style = MaterialTheme.typography.titleMedium)
                Text("هدف، کامل بودن نیست؛ هدف، آگاه‌تر شدن است.")
            }
        }
    }
}

@Composable
fun DailyEntryScreen(store: AppStore, done: () -> Unit) {
    var hunger by remember { mutableFloatStateOf(store.hunger.toFloat()) }
    var fullness by remember { mutableFloatStateOf(store.fullness.toFloat()) }
    var emotional by remember { mutableStateOf(store.emotional) }
    var mindful by remember { mutableStateOf(store.mindful) }
    var paused by remember { mutableStateOf(store.paused) }
    var satisfiedStop by remember { mutableStateOf(store.satisfiedStop) }
    var note by remember { mutableStateOf(store.note) }
    var saved by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())
    ) {
        Text("ثبت امروز", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(18.dp))

        Text("قبل از غذا چقدر گرسنه بودید؟ ${hunger.roundToInt()} از ۱۰")
        Slider(hunger, { hunger = it }, valueRange = 1f..10f, steps = 8)

        Text("بعد از غذا چقدر احساس سیری داشتید؟ ${fullness.roundToInt()} از ۱۰")
        Slider(fullness, { fullness = it }, valueRange = 1f..10f, steps = 8)

        CheckRow("آیا امروز به دلیل احساسات غذا خوردید؟", emotional) { emotional = it }
        CheckRow("آیا قبل از ریزه‌خواری مکث کردم؟", paused) { paused = it }
        CheckRow("آیا غذا را آهسته و آگاهانه خوردم؟", mindful) { mindful = it }
        CheckRow("آیا با رضایت و سیری متوقف شدم؟", satisfiedStop) { satisfiedStop = it }

        OutlinedTextField(
            value = note, onValueChange = { note = it },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            label = { Text("نکته، احساس یا موفقیت امروز") },
            minLines = 4
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                store.hunger = hunger.roundToInt()
                store.fullness = fullness.roundToInt()
                store.emotional = emotional
                store.mindful = mindful
                store.paused = paused
                store.satisfiedStop = satisfiedStop
                store.note = note
                if (store.registeredDays < 60) store.registeredDays += 1
                saved = true
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ذخیره ثبت امروز") }

        if (saved) {
            Spacer(Modifier.height(14.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("آفرین 🌱", style = MaterialTheme.typography.titleMedium)
                    Text("ثبت امروز با موفقیت ذخیره شد.", textAlign = TextAlign.Center)
                    TextButton(onClick = done) { Text("بازگشت به صفحه اصلی") }
                }
            }
        }
    }
}

@Composable
fun CheckRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Switch(checked = checked, onCheckedChange = onChange)
        Spacer(Modifier.width(10.dp))
        Text(text, modifier = Modifier.weight(1f))
    }
}

@Composable
fun ProgressScreen(store: AppStore) {
    var refresh by remember { mutableIntStateOf(0) }
    val days = store.registeredDays
    val cards = listOf(
        "روزهای ثبت‌شده" to "$days از ۶۰",
        "آخرین گرسنگی ثبت‌شده" to "${store.hunger} از ۱۰",
        "آخرین سیری ثبت‌شده" to "${store.fullness} از ۱۰",
        "خوردن آگاهانه" to if (store.mindful) "ثبت شده ✓" else "هنوز ثبت نشده"
    )
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState())) {
        Text("پیشرفت من", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        cards.forEach { (title, value) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(title)
                    Text(value)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        LinearProgressIndicator(
            progress = { days / 60f },
            modifier = Modifier.fillMaxWidth().height(10.dp)
        )
        Spacer(Modifier.height(8.dp))
        Text("با ثبت اطلاعات روزهای بیشتر، این بخش می‌تواند به نمودارهای کامل ۶۰ روزه ارتقا پیدا کند.")
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { refresh++ }) { Text("به‌روزرسانی اطلاعات") }
    }
}

@Composable
fun GuideScreen() {
    val items = listOf(
        "هر روز فقط چند دقیقه برای ثبت عملکردتان وقت بگذارید؛ لازم نیست همه چیز کامل باشد.",
        "برای گرسنگی و سیری از مقیاس ۱ تا ۱۰ استفاده کنید.",
        "اگر خوردن احساسی داشتید، احساس یا محرک خود را یادداشت کنید.",
        "مکث قبل از ریزه‌خواری و خوردن آگاهانه را به عنوان تمرین ثبت کنید.",
        "این اپلیکیشن ابزار خودپایش است و جایگزین تشخیص یا درمان پزشکی نیست."
    )
    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
        Text("راهنمای شروع", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        items.forEachIndexed { i, item ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text("${i + 1}. $item", Modifier.padding(16.dp))
            }
        }
    }
}
